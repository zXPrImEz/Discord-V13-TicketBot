const { SlashCommandBuilder } = require("@discordjs/builders");

const { MessageEmbed, MessageButton, MessageActionRow, Interaction } = require("discord.js");

const ticketOptions = [
  {
    id: "test_question",
    name: "Open Ticket",
    icon: "🔓",
  },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName("sendticketpanel")
    .setDescription("Send ticket panel message"),
  permissions: [
    {
      id: "840318236499247117",
      type: "ROLE",
      permission: true,
    },
  ],
  defaultPermission: false,
  async execute(client, interaction) {
    let formatted = "";
    const buttonArray = [];

    ticketOptions.forEach((option) => {
      formatted = formatted + `\n${option.icon} ┃ ${option.name}`;
      buttonArray.push(
        new MessageActionRow().addComponents(
          new MessageButton()
            .setCustomId("ticket_open")
            .setLabel("Open Ticket")
            .setStyle("SUCCESS")
            .setEmoji("🔓"),
        )
      );
    });

    const userEmbed = new MessageEmbed()
      .setColor("#3D040A")
      .setTitle("zxprimez.xyz $ Ticket System")
      .addField(
        "__**Ticket-Support**__",
        "Drücke einen, deines Anliegen entsprechenden, Knopf, um ein Ticket zu erstellen.\nBitte beachte jedoch, dass außerhalb der Supportzeiten (12:00-21:00 Uhr), sowie an\nSonn- und Feiertagen kein Support garantiert wird.",
        false
      )
      .addField("__**Kategorien**__", formatted, false)
      .setThumbnail(
        "https://cdn.discordapp.com/attachments/816944198858965014/885285581779795978/standard_6.gif"
      )
      .setFooter("👑 zxprimez.xyz")
      .setTimestamp();

    await interaction.reply({
      embeds: [userEmbed],
      components: buttonArray,
    });
  },
  async interaction(client, interaction) {
    const customId = interaction.customId.split("ticket_")[1];

    if (customId === "close") {
      const userEmbed = new MessageEmbed()
        .setColor("#3D040A")
        .setTitle("zxprimez.xyz $ Ticket System")
        .setDescription("Ticket will close in 5 seconds!")
        .setThumbnail(
          "https://cdn.discordapp.com/attachments/816944198858965014/885285581779795978/standard_6.gif"
        )
        .setFooter("👑 zxprimez.xyz")
        .setTimestamp();

      interaction.reply({ embeds: [userEmbed] }).then(msg => {
        setTimeout(() => interaction.channel.delete(), 5000)
      })
      return;
    }

    const channelName = `🎫┃${interaction.user.username}@${interaction.user.discriminator}`;

    let ticketObject = undefined;

    ticketOptions.forEach((ticket) => {
      if (ticket.id === customId) {
        ticketObject = ticket;
        return;
      }
    });

    if (
      !interaction.guild.channels.cache.find(
        (c) => c.name.toLowerCase() === channelName
      )
    ) {

      if (customId === "reopen") {
        interaction.guild.channels
          .create(channelName, {
            parent: "816944172874465280",
          })
          .then((newChannel) => {
            const ticketCreatedEmbed = new MessageEmbed()
              .setColor("#3D040A")
              .setTitle("You've opened a ticket!")
              .setDescription(
                "Support will be with you shorty."
              )
              .setThumbnail(
                "https://cdn.discordapp.com/attachments/816944198858965014/885285581779795978/standard_6.gif"
              )
              .setFooter("👑 zxprimez.xyz")
              .setTimestamp();
              interaction.channel.delete()

            newChannel.send({
              embeds: [ticketCreatedEmbed],
              components: [
                new MessageActionRow().addComponents(
                  new MessageButton()
                    .setCustomId("ticket_close")
                    .setLabel("Close Ticket")
                    .setStyle("DANGER")
                    .setEmoji("🔒"),

                  new MessageButton()
                    .setCustomId("ticket_reopen")
                    .setLabel("Reopen Ticket")
                    .setStyle("PRIMARY")
                    .setEmoji("🔓"),
                ),
              ],
            });
          });
      }

      if (customId === "open") {
        !interaction.guild.channels
          .create(channelName, {
            parent: "816944172874465280",
          })
          .then((newChannel) => {
            const ticketCreatedEmbed = new MessageEmbed()
              .setColor("#3D040A")
              .setTitle("You've opened a ticket!")
              .setDescription(
                "Support will be with you shorty."
              )
              .setThumbnail(
                "https://cdn.discordapp.com/attachments/816944198858965014/885285581779795978/standard_6.gif"
              )
              .setFooter("👑 zxprimez.xyz")
              .setTimestamp();

            newChannel.send({
              embeds: [ticketCreatedEmbed],
              components: [
                new MessageActionRow().addComponents(
                  new MessageButton()
                    .setCustomId("ticket_close")
                    .setLabel("Close Ticket")
                    .setStyle("DANGER")
                    .setEmoji("🔒"),

                  new MessageButton()
                    .setCustomId("ticket_reopen")
                    .setLabel("Reopen Ticket")
                    .setStyle("PRIMARY")
                    .setEmoji("🔓"),
                ),
              ],
            });
          });
      }

    }
  },
};



