const { TOKEN, GUILD_ID } = require("./config");

const { Client, Intents } = require("discord.js");

const client = new Client({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MEMBERS],
});

const CommandLoader = require("./loaders/CommandLoader");

client.on("ready", async () => {
  console.log(`Logged in as ${client.user.tag}!`);
  try {
    CommandLoader.load(client);
  } catch (error) {
    console.error(error);
  }
});

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isCommand()) {
    let customId = interaction.customId;

    if(customId) {
      if(customId.startsWith("ticket_")) {
        CommandLoader.commandList.get("sendticketpanel").interaction(client, interaction);
        return;
      }
    }
  }

  if (!(interaction.user.id === "285517169503109121")) {
    await interaction.reply({
      content:
        "This command is only available to <@285517169503109121> at this time",
      ephemeral: true,
    });
    return;
  }

  const { commandName } = interaction;

  if (!CommandLoader.commandList.has(commandName)) return;

  try {
    await CommandLoader.commandList
      .get(commandName)
      .execute(client, interaction);
  } catch (error) {
    console.error(error);
    await interaction.reply({
      content: "There was an error while executing this command!",
      ephemeral: true,
    });
  }
});

client.login(TOKEN);
console.log("From zxprimez")
