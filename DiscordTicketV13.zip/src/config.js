module.exports = {
    TOKEN: 'BOT_TOKEN',
    CLIENT_ID: 'BOT_CLIENT_ID',
    GUILD_ID: 'SERVER_ID'
}