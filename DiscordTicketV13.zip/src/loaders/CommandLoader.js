const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v9");
const { Collection } = require("discord.js");
const { TOKEN, CLIENT_ID, GUILD_ID } = require("../config");

const AsciiTable = require("ascii-table");
const path = require("path");

const commandList = new Collection();

const rest = new REST({
  version: "9",
}).setToken(TOKEN);

module.exports = {
  load: async (client) => {
    let table = new AsciiTable("Commands");

    table.setHeading("Command", "Load status");

    const commands = readdirSync(`./src/commands/`).filter((file) =>
      file.endsWith(".js")
    );
    for (let file of commands) {
      let pull = require(path.join(process.cwd(), `src/commands/${file}`));
      if (pull.data) {
        commandList.set(pull.data.name, pull);
        table.addRow(file, "✅");
      } else {
        table.addRow(file, "❌ -> Missing data object");
        continue;
      }
    }

    console.log(table.toString());

    const builderList = [];

    commandList.forEach((command) => {
      builderList.push(command.data);
    });

    await rest
      .put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), {
        body: builderList,
      })
      .then(async (response) => {
        const responseTable = new AsciiTable("Slashcommands Response");

        responseTable.setHeading("Command", "Id");

        const fullPermissions = [];

        const cmdArray = [];

        response.forEach((cmd) => {
          responseTable.addRow(cmd.name, cmd.id);
          fullPermissions.push({
            id: cmd.id,
            permissions: commandList.get(cmd.name).permissions,
          });
          cmdArray.push({
            id: cmd.id,
            object: commandList.get(cmd.name),
          });
        });

        console.log(responseTable.toString());

        const guild = client.guilds.cache.get(GUILD_ID);

        await guild?.commands.permissions
          .set({ fullPermissions })
          .then((response) => {
            console.log(response);
          });
      });
  },
  commandList: commandList,
};
